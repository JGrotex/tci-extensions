# TCI MQTT Extension
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

first draft Version with just a publish to a MQTT Gateway.

 

## Activities
available Activities so far
### MQTT Publish
Sample publish to a MQTT topic,

Input
- host          string
- username      string
- password      string
- topic         string
- msg           string

<i>Hint:</i> none yet.

Output
- send               bool   `json:"send"`
  
Sample Input Data


Sample Output Data

``json:
{"send":true}
``

<hr>
<sub><b>Note:</b> more TCI Extensions can be found here: https://tibcosoftware.github.io/tci-awesome/ </sub>
